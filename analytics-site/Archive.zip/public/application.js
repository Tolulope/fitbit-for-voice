var mainApplicationModuleName= 'cityhack';
var mainApp= angular.module(mainApplicationModuleName, ['ui.bootstrap', 'ngMaterial', 'ngMessages', 'chart.js']);

//a parametized get event
//Factory function to get latitude, longitude using address
mainApp.factory('getRecordings', ['$http',  function($http){
    return $http.get("/listRecordings");  
}]);


mainApp.controller('mainController',['$scope','$timeout', 'getRecordings','$mdToast' , "$mdDialog",function($scope, $timeout, getRecordings,$mdToast, $mdDialog){
    var self=this;
    $scope.recordings=[];
    getRecordings.success(function(data){
        console.log("successfully retrieved recordings", data);
        $scope.recordings=data;
        //$scope.$apply();
    }).error(function(error,status){
        console.log(error);
        
    });

    //$scope.$watch('[recordings]', function(newValues, oldValues, $scope) {
        
    //    var record=newValues[0];
    //    console.log(record);
        //$scope.$apply();
    //});

}]);